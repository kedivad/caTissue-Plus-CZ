//v.2.5 build 91111

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/
dhtmlXLayoutObject.prototype.tplData["4A"] = '<layout><autosize hor="d" ver="b;c;d" rows="2" cols="3"/><table data="a,c,d;b,c,d"/><row><cell obj="a" wh="3,2" resize="ver" neighbors="a;b"/><cell sep="ver" left="a,b" right="c;d" dblclick="c" rowspan="3"/><cell obj="c" wh="3,1" resize="hor" neighbors="a,b;c;d" rowspan="3"/><cell sep="ver" left="a,b;c" right="d" dblclick="d" rowspan="3"/><cell obj="d" wh="3,1" resize="hor" neighbors="a,b;c;d" rowspan="3"/></row><row sep="true"><cell sep="hor" top="a" dblclick="a" bottom="b"/></row><row><cell obj="b" wh="a,2" resize="ver" neighbors="a;b"/></row></layout>';dhtmlXLayoutObject.prototype._availAutoSize["4A_hor"] = new Array("a;b", "c", "d");dhtmlXLayoutObject.prototype._availAutoSize["4A_ver"] = new Array("a;c;d", "b;c;d");

//v.2.5 build 91111

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/