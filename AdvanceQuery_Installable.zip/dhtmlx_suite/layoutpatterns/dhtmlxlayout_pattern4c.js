//v.2.5 build 91111

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/
dhtmlXLayoutObject.prototype.tplData["4C"] = '<layout><autosize hor="b;c;d" ver="a;d" rows="3" cols="2"/><table data="a,b;a,c;a,d"/><row><cell obj="a" wh="2,1" resize="hor" neighbors="a;b,c,d" rowspan="5"/><cell sep="ver" left="a" right="b,c,d" dblclick="a" rowspan="5"/><cell obj="b" wh="2,3" resize="ver" neighbors="b;c;d"/></row><row sep="yes"><cell sep="hor" top="b" bottom="c;d" dblclick="b"/></row><row><cell obj="c" wh="2,3" resize="ver" neighbors="b;c;d"/></row><row sep="yes"><cell sep="hor" top="b;c" bottom="d" dblclick="c"/></row><row><cell obj="d" wh="2,3" resize="ver" neighbors="b;c;d"/></row></layout>';dhtmlXLayoutObject.prototype._availAutoSize["4C_hor"] = new Array("a", "b;c;d");dhtmlXLayoutObject.prototype._availAutoSize["4C_ver"] = new Array("a;b", "a;c", "a;d");

//v.2.5 build 91111

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/