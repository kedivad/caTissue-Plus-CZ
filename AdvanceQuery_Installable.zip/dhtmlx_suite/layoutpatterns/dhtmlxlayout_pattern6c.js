//v.2.5 build 91111

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/
dhtmlXLayoutObject.prototype.tplData["6C"] = '<layout><autosize hor="b;c;d;e;f" ver="a;f" rows="5" cols="2"/><table data="a,b;a,c;a,d;a,e;a,f"/><row><cell obj="a" wh="2,1" resize="hor" neighbors="a;b,c,d,e,f" rowspan="9"/><cell sep="ver" left="a" right="b,c,d,e,f" dblclick="a" rowspan="9"/><cell obj="b" wh="2,5" resize="ver" neighbors="b;c;d;e;f"/></row><row sep="yes"><cell sep="hor" top="b" bottom="c;d;e;f" dblclick="b"/></row><row><cell obj="c" wh="2,5" resize="ver" neighbors="b;c;d;e;f"/></row><row sep="yes"><cell sep="hor" top="b;c" bottom="d;e;f" dblclick="c"/></row><row><cell obj="d" wh="2,5" resize="ver" neighbors="b;c;d;e;f"/></row><row sep="yes"><cell sep="hor" top="b;c;d" bottom="e;f" dblclick="c"/></row><row><cell obj="e" wh="2,5" resize="ver" neighbors="b;c;d;e;f"/></row><row sep="yes"><cell sep="hor" top="b;c;d;e" bottom="f" dblclick="c"/></row><row><cell obj="f" wh="2,5" resize="ver" neighbors="b;c;d;e;f"/></row></layout>';dhtmlXLayoutObject.prototype._availAutoSize["6C_hor"] = new Array("a", "b;c;d;e;f");dhtmlXLayoutObject.prototype._availAutoSize["6C_ver"] = new Array("a;b", "a;c", "a;d", "a;e", "a;f");

//v.2.5 build 91111

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/